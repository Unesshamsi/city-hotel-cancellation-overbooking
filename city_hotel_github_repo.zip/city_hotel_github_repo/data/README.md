# Data

Do not commit private or customer-level booking data to Git.

The source is the Hotel Booking Demand dataset; this project uses the City Hotel (H2) subset. The supplied project bundle contains the cleaned data and supporting analysis outputs outside this repository.

External data status:
- Portugal public holidays: available in the supplied bundle.
- Lisbon weather: not supplied.
- Google Trends: not supplied.

Use the project bundle or an authorised current-data source to reproduce the analysis.
