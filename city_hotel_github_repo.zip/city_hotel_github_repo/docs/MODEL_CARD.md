# Model Card — City Hotel Cancellation Risk

## Intended use
Decision support for cancellation-risk ranking, overbooking simulation and deposit-policy experimentation.

## Models
- Booking-time logistic regression: ROC-AUC 0.750
- Booking-time GBM + isotonic calibration: ROC-AUC 0.775
- Near-arrival GBM + isotonic calibration: ROC-AUC 0.800

## Limitations
- Historical 2015–2017 Portuguese City Hotel data.
- Capacity is not in the data; 60 rooms is an explicit modelling assumption.
- Deposit response is scenario-based, not causal.
- Country must not be used as a direct deposit-pricing rule without documented fairness review.
