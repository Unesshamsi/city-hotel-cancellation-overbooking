from pathlib import Path

def test_project_structure():
    root = Path(__file__).resolve().parents[1]
    assert (root / "src" / "01_audit_clean_features.py").exists()
    assert (root / "src" / "02_eda_charts.py").exists()
    assert (root / "src" / "03_model_policy_analysis.py").exists()
    assert (root / "outputs" / "model_metrics.csv").exists()
