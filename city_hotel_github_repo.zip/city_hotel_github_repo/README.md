# City Hotel Cancellation, Overbooking & Deposit Policy

## What this repo contains
A reproducible pipeline for:
1. data audit, cleaning and feature engineering;
2. cancellation-risk modelling;
3. out-of-time probability calibration;
4. SHAP explanations;
5. overbooking profit simulation;
6. deposit-policy simulation.

## Structure

```text
.
├── README.md
├── requirements.txt
├── src/
│   ├── 01_audit_clean_features.py
│   ├── 02_eda_charts.py
│   ├── 03_model_policy_analysis.py
│   └── run_analysis.py
├── data/
│   └── README.md
├── outputs/
├── docs/
│   └── MODEL_CARD.md
└── tests/
    └── test_smoke.py
```

## Reproduction

1. `pip install -r requirements.txt`
2. Provide the authorised source hotel-booking data.
3. Run `python src/01_audit_clean_features.py`.
4. Run `python src/02_eda_charts.py`.
5. Run `python src/03_model_policy_analysis.py`.

## Temporal design
- Train: through 2016-12-12
- Calibration: 2016-12-13 to 2017-02-24
- Test: 2017-02-25 to 2017-08-31

## Current headline outputs
- Booking-time GBM ROC-AUC: 0.775
- Near-arrival GBM ROC-AUC: 0.800
- Base overbooking: k=10 at assumed 60-room capacity
- Base walk cost: €200
- Deposit tiers: 0% / 10% / 25% for <20% / 20–40% / >40% predicted risk

## Governance
Country is a fairness-monitoring attribute rather than a recommended deposit-pricing rule. Keep human override, log policy changes, version assumptions and recalibrate on current data before production.

## Data provenance
Antonio, N., de Almeida, A. & Nunes, L. (2019). *Hotel booking demand datasets*. Data in Brief, 22, 41–49. DOI: 10.1016/j.dib.2018.11.126.

Google Trends and Lisbon weather were not supplied in the current project bundle; do not fabricate them.
