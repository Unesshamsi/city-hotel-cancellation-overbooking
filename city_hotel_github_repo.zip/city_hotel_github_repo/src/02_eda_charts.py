"""
02_eda_charts.py
================
Stage (c): Exploratory Data Analysis — 8 charts, each with a one-line
managerial insight, using the cleaned City Hotel dataset produced by
01_audit_clean_features.py.

Outputs:
    charts/01..08_*.png     - the 8 charts
    data/processed/eda_insights.md - one-line insight per chart (also printed)
"""

import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

OUT_CHARTS = "../charts"
OUT_DATA = "../data/processed"
os.makedirs(OUT_CHARTS, exist_ok=True)

# --- palette (validated categorical order from the dataviz skill, light mode) ---
BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = (
    "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948")
INK = "#0b0b0b"
MUTED = "#6b6a66"
GRID = "#e4e3df"
SURFACE = "#fcfcfb"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
    "axes.edgecolor": GRID, "axes.labelcolor": INK, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
})

df = pd.read_csv(f"{OUT_DATA}/city_hotel_clean.csv", parse_dates=["arrival_date", "booking_date"])
insights = []


def note(n, text):
    print(f"[{n}] {text}")
    insights.append(f"**Chart {n}.** {text}")


def savefig(path):
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    plt.close()


# ---------------------------------------------------------------------------
# 1. Cancellation rate by lead-time bucket
# ---------------------------------------------------------------------------
bins = [0, 7, 30, 90, 180, 365, 1000]
labels = ["0-7d", "8-30d", "31-90d", "91-180d", "181-365d", "365d+"]
df["lead_bucket"] = pd.cut(df.lead_time, bins=bins, labels=labels, include_lowest=True)
g = df.groupby("lead_bucket", observed=True).is_canceled.mean()

plt.figure(figsize=(7, 4.2))
plt.bar(g.index.astype(str), g.values, color=BLUE, width=0.6)
plt.ylabel("Cancellation rate")
plt.title("Cancellation rate rises sharply with lead time")
for i, v in enumerate(g.values):
    plt.text(i, v + 0.01, f"{v:.0%}", ha="center", color=MUTED, fontsize=9)
savefig(f"{OUT_CHARTS}/01_cancel_by_lead_time.png")
note(1, f"Bookings made 365+ days ahead cancel {g.iloc[-1]:.0%} of the time vs. "
        f"{g.iloc[0]:.0%} for bookings made within a week of arrival — "
        f"flag anything beyond a ~90-day lead time for earlier confirmation outreach or a deposit.")

# ---------------------------------------------------------------------------
# 2. Cancellation rate by deposit type
# ---------------------------------------------------------------------------
g2 = df.groupby("deposit_type").is_canceled.agg(["mean", "size"])
plt.figure(figsize=(6, 4.5))
colors = [BLUE, RED, ORANGE]
plt.bar(g2.index, g2["mean"], color=colors, width=0.55)
for i, (m, s) in enumerate(zip(g2["mean"], g2["size"])):
    plt.text(i, m + 0.03, f"{m:.0%}\n(n={s:,})", ha="center", color=MUTED, fontsize=9)
plt.ylabel("Cancellation rate")
plt.ylim(0, 1.15)
plt.title("Non Refund bookings cancel almost every time")
savefig(f"{OUT_CHARTS}/02_cancel_by_deposit_type.png")
nr_rate = g2.loc["Non Refund", "mean"]
note(2, f"Non-Refund deposit bookings cancel {nr_rate:.0%} of the time, vs. "
        f"{g2.loc['No Deposit','mean']:.0%} for No Deposit — the opposite of what a "
        f"non-refundable deposit should achieve, and investigated in Chart 7/8 below.")

# ---------------------------------------------------------------------------
# 3. Cancellation rate by market segment
# ---------------------------------------------------------------------------
g3 = df.groupby("market_segment").is_canceled.agg(["mean", "size"])
g3 = g3[g3["size"] >= 50].sort_values("mean")  # drop 'Undefined' (n=2), not a reliable rate
plt.figure(figsize=(7.5, 4.5))
plt.barh(g3.index, g3["mean"], color=AQUA)
for i, (m, s) in enumerate(zip(g3["mean"], g3["size"])):
    plt.text(m + 0.01, i, f"{m:.0%} (n={s:,})", va="center", color=MUTED, fontsize=9)
plt.xlabel("Cancellation rate")
plt.title("Online TA and Groups carry the most cancellation risk")
savefig(f"{OUT_CHARTS}/03_cancel_by_segment.png")
top_seg = g3.index[-1]
note(3, f"'{top_seg}' and 'Groups' cancel at {g3['mean'].iloc[-1]:.0%} and "
        f"{g3.loc['Groups','mean']:.0%} respectively — more than 3x Complementary/Corporate "
        f"({g3['mean'].iloc[0]:.0%}) — so OTA and group channels deserve stricter deposit or "
        f"overbooking treatment than direct/corporate business.")

# ---------------------------------------------------------------------------
# 4. Monthly cancellation trend with holiday density overlay
# ---------------------------------------------------------------------------
df["arrival_ym"] = df.arrival_date.dt.to_period("M").dt.to_timestamp()
monthly = df.groupby("arrival_ym").agg(cancel_rate=("is_canceled", "mean"),
                                        holiday_arrivals=("is_arrival_holiday", "sum"))
# 2015-07 is a partial first month (n=393) and a volatile outlier; exclude it from the
# trend line's headline read but keep it plotted for completeness.
yearly = df.groupby(df.arrival_date.dt.year).is_canceled.mean()

fig, ax1 = plt.subplots(figsize=(9, 4.5))
ax1.plot(monthly.index, monthly.cancel_rate, color=BLUE, linewidth=2, marker="o", markersize=3)
ax1.set_ylabel("Cancellation rate", color=BLUE)
ax1.set_title("Cancellation rate has climbed steadily year over year")
ax2 = ax1.twinx()
ax2.bar(monthly.index, monthly.holiday_arrivals, color=ORANGE, alpha=0.3, width=20)
ax2.set_ylabel("Holiday arrivals in month (bars)", color=ORANGE)
ax2.grid(False)
savefig(f"{OUT_CHARTS}/04_monthly_trend_holidays.png")
note(4, f"Excluding the partial first month, cancellation rate rose from "
        f"{yearly.loc[2015]:.0%} in 2015 to {yearly.loc[2016]:.0%} in 2016 to "
        f"{yearly.loc[2017]:.0%} in 2017, with no strong recurring seasonal pattern — "
        f"the hotel's cancellation exposure is structurally worsening year over year, which "
        f"an overbooking/deposit policy fixed at 2015-2016 levels will under-correct for.")

# ---------------------------------------------------------------------------
# 5. ADR distribution: cancelled vs. completed stays
# ---------------------------------------------------------------------------
plt.figure(figsize=(6.5, 4.5))
data = [df.loc[df.is_canceled == 0, "adr"].clip(upper=400),
        df.loc[df.is_canceled == 1, "adr"].clip(upper=400)]
bp = plt.boxplot(data, tick_labels=["Completed", "Canceled"], patch_artist=True, widths=0.5,
                  medianprops=dict(color=INK))
for patch, c in zip(bp["boxes"], [BLUE, RED]):
    patch.set_facecolor(c)
    patch.set_alpha(0.55)
plt.ylabel("ADR (€, clipped at 400 for display)")
plt.title("Cancelled bookings carry a slightly higher room rate")
savefig(f"{OUT_CHARTS}/05_adr_by_outcome.png")
med_c = df.loc[df.is_canceled == 0, "adr"].median()
med_x = df.loc[df.is_canceled == 1, "adr"].median()
note(5, f"Median ADR is €{med_x:.0f} for cancelled vs. €{med_c:.0f} for completed bookings — "
        f"higher-rate bookings are somewhat more cancellation-prone, so a deposit tied to a "
        f"% of room value also protects the highest-revenue-at-risk bookings.")

# ---------------------------------------------------------------------------
# 6. Lead time distribution: Non Refund vs No Deposit (supports the paradox)
# ---------------------------------------------------------------------------
plt.figure(figsize=(6.5, 4.5))
nr = df.loc[df.deposit_type == "Non Refund", "lead_time"].clip(upper=500)
nd = df.loc[df.deposit_type == "No Deposit", "lead_time"].clip(upper=500)
plt.hist(nd, bins=40, alpha=0.55, label=f"No Deposit (median {nd.median():.0f}d)", color=BLUE, density=True)
plt.hist(nr, bins=40, alpha=0.55, label=f"Non Refund (median {nr.median():.0f}d)", color=RED, density=True)
plt.xlabel("Lead time (days, clipped at 500)")
plt.ylabel("Density")
plt.legend(frameon=False)
plt.title("Non-Refund bookings are booked far earlier, not closer to arrival")
savefig(f"{OUT_CHARTS}/06_leadtime_nonrefund_vs_nodeposit.png")
note(6, f"Non-Refund bookings have a median lead time of {nr.median():.0f} days vs. "
        f"{nd.median():.0f} for No Deposit, with near-zero special requests or parking asks — "
        f"a pattern consistent with advance tour-operator room allotments, not individual "
        f"guests who paid a non-refundable rate and should be *less* likely to cancel.")

# ---------------------------------------------------------------------------
# 7. Non-Refund country / segment composition (the "why" chart)
# ---------------------------------------------------------------------------
nr_df = df[df.deposit_type == "Non Refund"]
country_share = nr_df.country.value_counts(normalize=True).head(6)
seg_share = nr_df.market_segment.value_counts(normalize=True)

fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
axes[0].bar(country_share.index, country_share.values, color=VIOLET)
axes[0].set_title("Non-Refund bookings: guest country")
axes[0].set_ylabel("Share of Non-Refund bookings")
for i, v in enumerate(country_share.values):
    axes[0].text(i, v + 0.01, f"{v:.0%}", ha="center", fontsize=8, color=MUTED)

axes[1].bar(seg_share.index, seg_share.values, color=MAGENTA)
axes[1].set_title("Non-Refund bookings: market segment")
axes[1].tick_params(axis="x", rotation=30)
for i, v in enumerate(seg_share.values):
    axes[1].text(i, v + 0.01, f"{v:.0%}", ha="center", fontsize=8, color=MUTED)
savefig(f"{OUT_CHARTS}/07_nonrefund_composition.png")
note(7, f"{country_share.iloc[0]:.0%} of Non-Refund bookings are domestic (Portugal) and "
        f"{seg_share.get('Groups',0)+seg_share.get('Offline TA/TO',0):.0%} sit in Groups/"
        f"Offline TA-TO — this is agent block-allotment inventory that gets released "
        f"(cancelled) when unsold, not individual leisure guests, so it should be excluded "
        f"from any 'non-refundable deposits deter cancellation' policy claim.")

# ---------------------------------------------------------------------------
# 8. Cancellation rate by days-to-nearest-holiday bucket
# ---------------------------------------------------------------------------
hbins = [0, 3, 7, 14, 30, 1000]
hlabels = ["0-3d", "4-7d", "8-14d", "15-30d", "30d+"]
df["holiday_bucket"] = pd.cut(df.days_to_nearest_holiday, bins=hbins, labels=hlabels, include_lowest=True)
g8 = df.groupby("holiday_bucket", observed=True).is_canceled.mean()
plt.figure(figsize=(7, 4.2))
plt.bar(g8.index.astype(str), g8.values, color=GREEN, width=0.6)
for i, v in enumerate(g8.values):
    plt.text(i, v + 0.01, f"{v:.0%}", ha="center", color=MUTED, fontsize=9)
plt.ylabel("Cancellation rate")
plt.title("Arrivals close to a public holiday cancel more, not less")
savefig(f"{OUT_CHARTS}/08_cancel_by_holiday_proximity.png")
note(8, f"Bookings arriving within 3 days of a Portuguese public holiday cancel at "
        f"{g8.iloc[0]:.0%} vs. {g8.iloc[-1]:.0%} for arrivals 30+ days from any holiday — "
        f"holiday periods likely draw more speculative/flexible-plan bookings, so widen "
        f"overbooking buffers and tighten deposit terms around holiday dates, not the reverse.")

with open(f"{OUT_DATA}/eda_insights.md", "w") as f:
    f.write("# EDA — 8 charts and managerial insights\n\n" + "\n\n".join(insights) + "\n")

print("\nSaved 8 charts to ../charts/ and insights to ../data/processed/eda_insights.md")
