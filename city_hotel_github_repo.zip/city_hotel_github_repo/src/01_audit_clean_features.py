"""
01_audit_clean_features.py
===========================
Project: Predicting City Hotel booking cancellations (Lisbon, Portugal)
Stage: (a) Audit  (b) Clean + Feature Engineering

Inputs  (data/raw/):
    hotel_bookings.csv   - Kaggle "Hotel Booking Demand" dataset (both hotels)
    pt_holidays.csv       - Portugal public holidays 2015-2017 (python `holidays` lib)
    weather_lisbon.csv    - OPTIONAL. Open-Meteo historical daily weather for Lisbon.
                            Columns expected: date, temperature_2m_max, temperature_2m_min,
                            precipitation_sum
    trends_*.csv          - OPTIONAL. One or more Google Trends weekly CSVs
                            (e.g. trends_lisbon_hotels.csv). Standard Google Trends
                            export format: first row "Category: ...", then a header
                            row "Week, <term>: (Worldwide)" below it.

Outputs (data/processed/):
    city_hotel_clean.csv      - cleaned, feature-engineered City Hotel dataset
    audit_report.md           - full data audit findings
    cleaning_decisions.csv    - one row per cleaning/engineering decision
    feature_dictionary.csv    - every model feature + "known at booking time" /
                                 "known only near arrival" label

Run:
    python3 01_audit_clean_features.py
"""

import glob
import os

import numpy as np
import pandas as pd

RAW = "../data/raw"
OUT = "../data/processed"
os.makedirs(OUT, exist_ok=True)

MONTH_MAP = {m: i for i, m in enumerate(
    ["January", "February", "March", "April", "May", "June",
     "July", "August", "September", "October", "November", "December"], 1)}

audit_lines = []           # collects markdown audit report
decisions = []             # collects cleaning-decision table rows


def log(msg):
    print(msg)
    audit_lines.append(msg)


def decide(step, finding, decision, rationale):
    decisions.append({"step": step, "finding": finding,
                       "decision": decision, "rationale": rationale})


# ---------------------------------------------------------------------------
# 0. LOAD + FILTER TO CITY HOTEL
# ---------------------------------------------------------------------------
log("# City Hotel — Data Audit Report\n")

raw = pd.read_csv(f"{RAW}/hotel_bookings.csv")
log(f"Loaded full dataset: {raw.shape[0]:,} rows, {raw.shape[1]} columns "
    f"({raw.hotel.value_counts().to_dict()})")

df = raw[raw["hotel"] == "City Hotel"].copy()
log(f"Filtered to **City Hotel**: {df.shape[0]:,} rows\n")
decide("Filter", "Dataset contains Resort Hotel + City Hotel",
       "Keep City Hotel rows only (79,330 of 119,390)",
       "Project scope is City Hotel cancellations only, per brief")

raw_cancel_rate = df["is_canceled"].mean()
log(f"Raw City Hotel cancellation rate (before any cleaning): {raw_cancel_rate:.3%}\n")

# ---------------------------------------------------------------------------
# 1. AUDIT — MISSING VALUES
# ---------------------------------------------------------------------------
log("## 1. Missing values\n")
miss = df.isna().sum()
miss = miss[miss > 0]
log(f"Columns with NaN: {miss.to_dict()}")
log(f"`agent`/`company` NaN: library convention for 'no agent' / 'no company' "
    f"(these are IDs, not text 'NULL' here since pandas already parsed NULL strings as NaN) "
    f"agent={df.agent.isna().sum():,}, company={df.company.isna().sum():,}\n")

decide("Missing: children", "4 rows have children=NaN",
       "Impute 0", "Median and mode of children is 0; 4 rows is negligible (<0.01%)")
decide("Missing: country", "24 rows have country=NaN",
       "Fill with 'Unknown' category", "Too few to drop; kept as its own category to avoid bias")
decide("Missing: agent", f"{df.agent.isna().sum():,} rows have agent=NaN",
       "Treat as 'no travel agent used' -> create has_agent flag (0/1); "
       "keep agent id as nullable categorical for optional use",
       "NaN here is structural (direct/company bookings have no agent id), not random missingness")
decide("Missing: company", f"{df.company.isna().sum():,} rows have company=NaN",
       "Treat as 'not a corporate-contracted booking' -> create has_company flag (0/1); "
       "drop raw company id from modelling features (95% missing, high cardinality, weak signal)",
       "NaN here is structural; raw id has little use once the flag captures the structural signal")

df["children"] = df["children"].fillna(0)
df["country"] = df["country"].fillna("Unknown")
df["has_agent"] = df["agent"].notna().astype(int)
df["has_company"] = df["company"].notna().astype(int)

# ---------------------------------------------------------------------------
# 2. AUDIT — DUPLICATES
# ---------------------------------------------------------------------------
log("## 2. Duplicate rows\n")
full_dup_mask = df.duplicated(keep="first")
n_dup = full_dup_mask.sum()
log(f"Exact full-row duplicates: {n_dup:,} rows (no booking-ID column exists in this dataset, "
    f"so a duplicate here means every single field, including dates and ADR, matches another row)")

dup_rate_by_deposit = df.assign(dup=df.duplicated(keep=False)).groupby("deposit_type")["dup"].mean()
log(f"Share of rows that are part of a duplicate group, by deposit type: "
    f"{dup_rate_by_deposit.round(3).to_dict()}")
log("-> Non Refund bookings are duplicated far more than No Deposit bookings "
    "(93% vs 21% of rows sit in a duplicate group), concentrated in Groups / Offline TA-TO "
    "segments with a handful of agents and long lead times — consistent with batch allotment "
    "bookings loaded repeatedly into the PMS rather than independent guest decisions.\n")

cancel_before = df["is_canceled"].mean()
df_dedup = df[~full_dup_mask].copy()
cancel_after = df_dedup["is_canceled"].mean()
log(f"Cancellation rate before dedup: {cancel_before:.3%}; after: {cancel_after:.3%}")

decide("Duplicates", f"{n_dup:,} exact full-row duplicates found, concentrated in Non Refund "
       "group/offline-TA bookings",
       "Drop exact duplicate rows, keep first occurrence",
       "No booking ID exists to confirm these are genuine repeat bookings vs. a load/export "
       "artifact; keeping them would let one real-world event be counted many times and "
       "would inflate the apparent cancellation rate and the Non-Refund cancellation story. "
       "This is documented as a key limitation, not silently removed.")
df = df_dedup

# ---------------------------------------------------------------------------
# 3. AUDIT — DATE ALIGNMENT
# ---------------------------------------------------------------------------
log("\n## 3. Date alignment\n")

df["arrival_date"] = pd.to_datetime(dict(
    year=df.arrival_date_year,
    month=df.arrival_date_month.map(MONTH_MAP),
    day=df.arrival_date_day_of_month))

df["booking_date"] = df["arrival_date"] - pd.to_timedelta(df["lead_time"], unit="D")
df["reservation_status_date"] = pd.to_datetime(df["reservation_status_date"])

log(f"Arrival dates span {df.arrival_date.min().date()} to {df.arrival_date.max().date()}")
log(f"Derived booking dates (arrival - lead_time) span "
    f"{df.booking_date.min().date()} to {df.booking_date.max().date()}")

iso_mismatch = (df.arrival_date.dt.isocalendar().week.astype(int) != df.arrival_date_week_number).sum()
log(f"`arrival_date_week_number` disagrees with the ISO calendar week of the reconstructed "
    f"arrival date for {iso_mismatch:,} rows ({iso_mismatch/len(df):.1%}) — the dataset's week "
    f"numbering is not ISO-8601. All week-based joins below use a week computed directly from "
    f"the reconstructed date, not the provided column.")

rsd_before_book = (df.reservation_status_date < df.booking_date).sum()
log(f"Rows where reservation_status_date precedes the derived booking date: {rsd_before_book:,} "
    f"(sanity check passed - 0 expected and found)")

checkout = df[df.reservation_status == "Check-Out"]
depart = checkout.arrival_date + pd.to_timedelta(
    checkout.stays_in_weekend_nights + checkout.stays_in_week_nights, unit="D")
match_rate = (checkout.reservation_status_date == depart).mean()
log(f"For Check-Out rows, reservation_status_date matches arrival+nights (departure date) "
    f"{match_rate:.2%} of the time — confirms the date fields are internally consistent.")

decide("Date alignment", "Provided week_number column is not ISO-compliant for ~59% of rows",
       "Recompute ISO week from the reconstructed arrival_date for any date-based join "
       "(holidays, weather, trends)",
       "Avoids silently misaligning external data joined by calendar week")
decide("Date reconstruction", "No explicit booking-date column exists",
       "Derive booking_date = arrival_date - lead_time",
       "Needed to know what was knowable 'at booking time' (e.g. that week's search interest) "
       "vs. only near arrival (e.g. that day's weather)")

# ---------------------------------------------------------------------------
# 4. AUDIT — OUTLIERS / INVALID ROWS
# ---------------------------------------------------------------------------
log("\n## 4. Outliers and invalid rows\n")

zero_guests = (df.adults + df.children + df.babies) == 0
log(f"Rows with 0 total guests (adults+children+babies): {zero_guests.sum():,}")
decide("Outlier: zero guests", f"{zero_guests.sum():,} rows booked with 0 total guests",
       "Drop these rows", "A booking with nobody staying is not a valid observation for "
       "cancellation modelling")
df = df[~zero_guests].copy()

adr_extreme = df.adr.nlargest(3)
log(f"Top ADR values: {adr_extreme.tolist()} (next highest after the top value is "
    f"{df.adr.nsmallest(len(df)).sort_values(ascending=False).iloc[1]:.0f}, "
    f"so the single {adr_extreme.iloc[0]:.0f} value is far outside the rest of the distribution)")
extreme_mask = df.adr > 1000
decide("Outlier: ADR", f"One row has adr={df.loc[extreme_mask,'adr'].tolist()} "
       f"(next highest is ~510), vs. a dataset median of {df.adr.median():.0f}",
       "Drop the single adr > 1000 row as a probable data-entry error",
       "A single isolated extreme value, ~10x the next highest, almost certainly reflects a "
       "mis-keyed rate rather than a real nightly price")
df = df[~extreme_mask].copy()

adr_zero = (df.adr == 0).sum()
log(f"Rows with adr=0: {adr_zero:,} ({df[df.adr==0].market_segment.value_counts().to_dict()})")
decide("ADR = 0", f"{adr_zero:,} rows have adr=0, mostly Complementary/comp stays",
       "Keep, flag with is_free_stay=1", "Zero-rate stays are a legitimate business category "
       "(complimentary rooms), not missing data")
df["is_free_stay"] = (df.adr == 0).astype(int)

zero_nights = (df.stays_in_weekend_nights + df.stays_in_week_nights) == 0
log(f"Rows with 0 total nights booked: {zero_nights.sum():,}")
decide("Zero-night bookings", f"{zero_nights.sum():,} rows book 0 nights",
       "Keep, flag with is_zero_night=1 (do not drop)",
       "Plausible for day-use or data-entry edge cases; too large a group to assume error, "
       "and dropping would lose otherwise valid cancellation signal")
df["is_zero_night"] = zero_nights.astype(int)

long_lead = (df.lead_time > 365).sum()
log(f"Rows with lead_time > 365 days: {long_lead:,} (max {df.lead_time.max()} days) - kept, "
    f"long-horizon bookings are plausible and not anomalous in this channel mix")
decide("Lead time outliers", f"{long_lead:,} rows with lead_time > 1 year",
       "Keep as-is, no capping", "Long lead times are real for group/corporate bookings and "
       "carry genuine cancellation signal (longer lead time correlates with higher cancellation)")

# ---------------------------------------------------------------------------
# 5. LEAKAGE COLUMNS
# ---------------------------------------------------------------------------
log("\n## 5. Leakage columns dropped\n")
leak_cols = ["reservation_status", "reservation_status_date"]
log(f"Dropping: {leak_cols} — these record the *outcome* (and when it was recorded), "
    f"so using them to predict is_canceled is circular leakage "
    f"(reservation_status perfectly encodes is_canceled: "
    f"{df.groupby('reservation_status').is_canceled.mean().to_dict() if 'reservation_status' in df else ''}).")
decide("Leakage", "reservation_status / reservation_status_date perfectly determine is_canceled",
       "Drop both columns entirely before modelling",
       "Using post-outcome fields to predict the outcome is leakage, not prediction")

df = df.drop(columns=leak_cols)

log("Also flagging (not dropping, but excluded from the booking-time feature set): "
    "`assigned_room_type` (assigned at/near check-in, can reflect upgrades after a near-"
    "cancellation reshuffle) and `booking_changes` (a cumulative count only fully known by "
    "the time of the final outcome — at the moment of booking it is always 0).")
decide("Near-arrival-only fields", "assigned_room_type and booking_changes reach their final "
       "recorded value only over the course of the stay lifecycle, not at booking time",
       "Label both 'known only near arrival' in the feature dictionary; exclude from a "
       "booking-time-only model, keep available for a near-arrival model",
       "A field whose value keeps changing after the booking is made cannot be used to score "
       "risk at the moment the booking is made")

# ---------------------------------------------------------------------------
# 6. FEATURE ENGINEERING — HOLIDAYS
# ---------------------------------------------------------------------------
log("\n## 6. Feature engineering: holidays\n")
hol = pd.read_csv(f"{RAW}/pt_holidays.csv", parse_dates=["date"])
holiday_dates = pd.DatetimeIndex(sorted(hol["date"]))

df["is_arrival_holiday"] = df["arrival_date"].isin(holiday_dates).astype(int)


def days_to_nearest_holiday(d):
    diffs = (holiday_dates - d).days
    return int(np.abs(diffs).min())


df["days_to_nearest_holiday"] = df["arrival_date"].map(days_to_nearest_holiday)
log(f"{df.is_arrival_holiday.sum():,} bookings arrive exactly on a Portuguese public holiday. "
    f"days_to_nearest_holiday ranges {df.days_to_nearest_holiday.min()}-"
    f"{df.days_to_nearest_holiday.max()} days (median {df.days_to_nearest_holiday.median():.0f}).")
decide("Feature: holidays", "pt_holidays.csv gives 35 PT public holidays 2015-2017",
       "Engineer is_arrival_holiday (binary) and days_to_nearest_holiday (integer, signless), "
       "joined on the reconstructed arrival_date",
       "Holiday calendars are published years in advance, so these are 'known at booking time' "
       "regardless of how far ahead the booking is made")

# ---------------------------------------------------------------------------
# 7. FEATURE ENGINEERING — WEATHER (near-arrival)
# ---------------------------------------------------------------------------
log("\n## 7. Feature engineering: arrival-date weather\n")
weather_path = f"{RAW}/weather_lisbon.csv"
if os.path.exists(weather_path):
    wx = pd.read_csv(weather_path)
    date_col = [c for c in wx.columns if "date" in c.lower() or "time" in c.lower()][0]
    wx[date_col] = pd.to_datetime(wx[date_col])
    wx = wx.rename(columns={date_col: "arrival_date"})
    keep = [c for c in wx.columns if c != "arrival_date"]
    df = df.merge(wx[["arrival_date"] + keep], on="arrival_date", how="left")
    log(f"Joined {weather_path} on arrival_date. Columns added: {keep}. "
        f"Unmatched arrival dates: {df[keep[0]].isna().sum():,}")
    decide("Feature: weather", "Open-Meteo Lisbon daily weather available",
           "Join max/min temperature and precipitation to the arrival_date",
           "Actual weather on the stay date is only knowable close to arrival, not at "
           "booking time, so it is labelled 'known only near arrival'")
else:
    log(f"**{weather_path} not found.** Weather features were NOT engineered. "
        f"Open-Meteo's archive API and the Google Trends site are both blocked by this "
        f"session's outbound network policy, so they could not be fetched automatically. "
        f"See README.md for exact manual-download steps; drop the file at this path and "
        f"re-run this script to add temp_max, temp_min and precip_sum.")
    decide("Feature: weather", "weather_lisbon.csv not available in this session "
           "(network policy blocks Open-Meteo)",
           "Pipeline supports it (see code) but columns are left absent; placeholder "
           "columns (temp_max_c, temp_min_c, precip_mm) added as NaN so downstream code "
           "does not break",
           "Documented gap rather than fabricated data; user can drop the file in and re-run")
    df["temp_max_c"] = np.nan
    df["temp_min_c"] = np.nan
    df["precip_mm"] = np.nan

# ---------------------------------------------------------------------------
# 8. FEATURE ENGINEERING — GOOGLE TRENDS (booking-week search index)
# ---------------------------------------------------------------------------
log("\n## 8. Feature engineering: search interest for the week of booking\n")
trend_files = glob.glob(f"{RAW}/trends_*.csv")
if trend_files:
    df["booking_week"] = df["booking_date"].dt.to_period("W").dt.start_time
    trend_frames = []
    for f in trend_files:
        name = os.path.splitext(os.path.basename(f))[0].replace("trends_", "")
        raw_t = pd.read_csv(f, skiprows=1)
        raw_t.columns = ["week", name]
        raw_t["week"] = pd.to_datetime(raw_t["week"])
        raw_t[name] = pd.to_numeric(raw_t[name], errors="coerce")
        trend_frames.append(raw_t.set_index("week")[name])
    trends = pd.concat(trend_frames, axis=1).sort_index()
    trends = trends.resample("W").mean().reset_index().rename(columns={"week": "booking_week"})
    df = df.merge(trends, on="booking_week", how="left")
    added_cols = list(trends.columns.drop("booking_week"))
    log(f"Joined {len(trend_files)} Google Trends file(s) on the booking week: {added_cols}. "
        f"Unmatched booking weeks: {df[added_cols[0]].isna().sum():,}")
    decide("Feature: search interest", "Google Trends weekly CSV(s) available",
           "Average each term's weekly index to the week containing booking_date",
           "Search interest at the time the booking was made is 'known at booking time' — "
           "it reflects demand/market conditions the guest and hotel both observed then")
else:
    log("**No trends_*.csv files found.** Search-interest features were NOT engineered. "
        "trends.google.com is blocked for both the shell and the web-fetch tool in this "
        "session (its export endpoint requires an interactive browser session and is also "
        "disallowed by robots.txt for automated fetches). See README.md for manual export "
        "steps; drop file(s) named trends_<term>.csv (standard Google Trends CSV export: "
        "a 'Category: ...' row then a 'Week,<term>' header) into data/raw/ and re-run.")
    decide("Feature: search interest", "trends_*.csv not available in this session "
           "(Google Trends blocked for automated access)",
           "Pipeline supports arbitrary trends_*.csv files (see code) but no search-index "
           "column is added; left absent rather than invented",
           "Documented gap rather than fabricated data; user can drop files in and re-run")

# ---------------------------------------------------------------------------
# 9. ADDITIONAL BOOKING-TIME FEATURES
# ---------------------------------------------------------------------------
log("\n## 9. Additional engineered features\n")
df["booking_dow"] = df["booking_date"].dt.dayofweek
df["booking_month"] = df["booking_date"].dt.month
df["arrival_dow"] = df["arrival_date"].dt.dayofweek
df["arrival_month"] = df["arrival_date"].dt.month
df["total_nights"] = df["stays_in_weekend_nights"] + df["stays_in_week_nights"]
df["total_guests"] = df["adults"] + df["children"] + df["babies"]
df["room_type_changed"] = (df["reserved_room_type"] != df["assigned_room_type"]).astype(int)
decide("Feature: calendar parts", "Raw data stores month as text / split date parts",
       "Derive booking_dow, booking_month, arrival_dow, arrival_month, total_nights, "
       "total_guests from the reconstructed dates", "Numeric/cyclical fields are easier for "
       "models to use than text month names or separately split date fields")
decide("Feature: room_type_changed", "reserved_room_type vs assigned_room_type can differ",
       "Flag room_type_changed=1 when they differ; label 'known only near arrival'",
       "The assignment is finalised at/near check-in, so this reflects information not "
       "available at the moment of booking")

log(f"Final cleaned + engineered City Hotel dataset: {df.shape[0]:,} rows, {df.shape[1]} columns")
log(f"Final cancellation rate: {df.is_canceled.mean():.3%}")

df.to_csv(f"{OUT}/city_hotel_clean.csv", index=False)

# ---------------------------------------------------------------------------
# 10. FEATURE DICTIONARY — known at booking time vs. known only near arrival
# ---------------------------------------------------------------------------
booking_time_features = {
    "lead_time": "Days between booking and arrival",
    "arrival_date_year": "Arrival year", "arrival_date_month": "Arrival month (text)",
    "arrival_date_week_number": "Arrival week number (dataset's own numbering)",
    "arrival_date_day_of_month": "Arrival day", "arrival_month": "Arrival month (numeric)",
    "arrival_dow": "Arrival day-of-week",
    "stays_in_weekend_nights": "Weekend nights booked", "stays_in_week_nights": "Week nights booked",
    "total_nights": "Total nights booked",
    "adults": "Adults on booking", "children": "Children on booking", "babies": "Babies on booking",
    "total_guests": "Total guests",
    "meal": "Meal plan selected", "country": "Guest country of origin",
    "market_segment": "Market segment", "distribution_channel": "Distribution channel",
    "is_repeated_guest": "Repeat guest flag",
    "previous_cancellations": "Guest's past cancellations",
    "previous_bookings_not_canceled": "Guest's past completed bookings",
    "reserved_room_type": "Room type requested at booking",
    "deposit_type": "Deposit type agreed at booking",
    "has_agent": "Booked via a travel agent (flag)", "has_company": "Corporate-contracted booking (flag)",
    "days_in_waiting_list": "Days booking sat on waiting list before confirmation",
    "customer_type": "Customer type", "adr": "Average daily rate agreed at booking",
    "is_free_stay": "Zero-rate / complimentary stay flag",
    "is_zero_night": "Zero-night booking flag",
    "required_car_parking_spaces": "Parking spaces requested",
    "total_of_special_requests": "Special requests made at booking",
    "booking_dow": "Day of week booking was made", "booking_month": "Month booking was made",
    "is_arrival_holiday": "Arrival date falls on a PT public holiday",
    "days_to_nearest_holiday": "Days to the nearest PT public holiday (either direction)",
    "search_index_<term>": "Google Trends index for the week of booking (if sourced)",
}
near_arrival_features = {
    "assigned_room_type": "Room type actually assigned (can change up to check-in)",
    "booking_changes": "Cumulative count of changes made to the booking (grows over time)",
    "room_type_changed": "Whether assigned room differs from reserved room",
    "temp_max_c": "Lisbon max temperature on arrival date (if sourced)",
    "temp_min_c": "Lisbon min temperature on arrival date (if sourced)",
    "precip_mm": "Lisbon precipitation on arrival date (if sourced)",
}
dropped_leakage = {
    "reservation_status": "Outcome field — directly encodes is_canceled",
    "reservation_status_date": "Date the outcome was recorded — only exists after the outcome",
}

rows = []
for name, desc in booking_time_features.items():
    rows.append({"feature": name, "description": desc, "known_at": "known at booking time"})
for name, desc in near_arrival_features.items():
    rows.append({"feature": name, "description": desc, "known_at": "known only near arrival"})
for name, desc in dropped_leakage.items():
    rows.append({"feature": name, "description": desc, "known_at": "DROPPED (leakage)"})

pd.DataFrame(rows).to_csv(f"{OUT}/feature_dictionary.csv", index=False)
pd.DataFrame(decisions).to_csv(f"{OUT}/cleaning_decisions.csv", index=False)

with open(f"{OUT}/audit_report.md", "w") as f:
    f.write("\n".join(audit_lines))

print("\nDone. Outputs written to data/processed/:")
print(" - city_hotel_clean.csv")
print(" - audit_report.md")
print(" - cleaning_decisions.csv")
print(" - feature_dictionary.csv")
