import os, json, warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, precision_recall_curve, roc_curve
from sklearn.calibration import calibration_curve
from sklearn.base import clone
from lightgbm import LGBMClassifier
from scipy.special import logit
import shap

BASE='/mnt/data/city_hotel_prompt2'
OUT=os.path.join(BASE,'analysis_final')
os.makedirs(OUT,exist_ok=True)
df=pd.read_csv(os.path.join(BASE,'data/processed/city_hotel_clean.csv'), parse_dates=['arrival_date','booking_date'])
y=df['is_canceled'].astype(int)

base_features=[
'lead_time','arrival_month','arrival_dow','stays_in_weekend_nights','stays_in_week_nights','total_nights',
'adults','children','babies','total_guests','meal','country','market_segment','distribution_channel',
'is_repeated_guest','previous_cancellations','previous_bookings_not_canceled','reserved_room_type',
'deposit_type','has_agent','has_company','days_in_waiting_list','customer_type','adr','is_free_stay',
'is_zero_night','required_car_parking_spaces','total_of_special_requests','booking_dow','booking_month',
'is_arrival_holiday','days_to_nearest_holiday']
near_features=base_features+['assigned_room_type','booking_changes','room_type_changed']

# Strict temporal split: first 70% train, next 15% calibration, last 15% final test.
cut70=df.booking_date.quantile(0.70); cut85=df.booking_date.quantile(0.85)
tr=df.booking_date<=cut70; ca=(df.booking_date>cut70)&(df.booking_date<=cut85); te=df.booking_date>cut85


def preprocessor(features):
    cats=[c for c in features if df[c].dtype=='object']; nums=[c for c in features if c not in cats]
    return ColumnTransformer([
        ('num',Pipeline([('imp',SimpleImputer(strategy='median')),('sc',StandardScaler())]),nums),
        ('cat',Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('oh',OneHotEncoder(handle_unknown='ignore',min_frequency=3))]),cats)
    ])

def calibrate_sigmoid(p,ycal,ptest):
    c=LogisticRegression(C=1e6,solver='lbfgs')
    c.fit(logit(np.clip(p,1e-6,1-1e-6)).reshape(-1,1),ycal)
    return c.predict_proba(logit(np.clip(ptest,1e-6,1-1e-6)).reshape(-1,1))[:,1], c

def calibrate_isotonic(p,ycal,ptest):
    c=IsotonicRegression(out_of_bounds='clip')
    c.fit(p,ycal)
    return c.predict(ptest), c

def ece(ytrue,pred,n_bins=10):
    bins=np.linspace(0,1,n_bins+1); ids=np.digitize(pred,bins[1:-1]); out=0
    rows=[]
    for b in range(n_bins):
        m=ids==b
        if m.sum()==0: continue
        ap=float(pred[m].mean()); ay=float(np.mean(ytrue[m])); w=float(m.mean()); out += w*abs(ap-ay)
        rows.append({'bin':b,'n':int(m.sum()),'predicted':ap,'observed':ay})
    return float(out),pd.DataFrame(rows)

models={}; metrics=[]; calibrations={}
for version,features,cal_method in [('booking_time',base_features,'sigmoid'),('near_arrival',near_features,'sigmoid')]:
    X=df[features]; pre=preprocessor(features)
    lr=Pipeline([('pre',pre),('clf',LogisticRegression(C=1.0,max_iter=1200,solver='liblinear'))])
    gb=Pipeline([('pre',clone(pre)),('clf',LGBMClassifier(n_estimators=350,learning_rate=0.035,num_leaves=31,subsample=0.9,colsample_bytree=0.85,reg_lambda=2.0,random_state=42,n_jobs=-1,verbosity=-1))])
    for name,model in [('logistic',lr),('gradient_boosting',gb)]:
        model.fit(X[tr],y[tr])
        pcal_raw=model.predict_proba(X[ca])[:,1]; ptest_raw=model.predict_proba(X[te])[:,1]
        if name=='gradient_boosting':
            # Isotonic gave better out-of-time calibration than sigmoid in a strict time calibration split.
            ptest,cal=calibrate_isotonic(pcal_raw,y[ca],ptest_raw); method='isotonic'
        else:
            ptest,cal=calibrate_sigmoid(pcal_raw,y[ca],ptest_raw); method='sigmoid'
        e,calbins=ece(y[te].to_numpy(),ptest,10)
        metrics.append({'version':version,'model':name,'calibration_method':method,'train_n':int(tr.sum()),'calibration_n':int(ca.sum()),'test_n':int(te.sum()),'test_cancel_rate':float(y[te].mean()),'roc_auc':roc_auc_score(y[te],ptest),'average_precision':average_precision_score(y[te],ptest),'brier':brier_score_loss(y[te],ptest),'ece_10':e})
        models[(version,name)]={'model':model,'calibrator':cal,'p_test':ptest,'p_test_raw':ptest_raw,'p_cal_raw':pcal_raw,'features':features,'calibration_method':method}
        # PR/ROC/calibration data
        pr_p,pr_r,_=precision_recall_curve(y[te],ptest); roc_fpr,roc_tpr,_=roc_curve(y[te],ptest)
        ctrue,cpred=calibration_curve(y[te],ptest,n_bins=10,strategy='quantile')
        pd.DataFrame({'recall':pr_r,'precision':pr_p}).to_csv(os.path.join(OUT,f'pr_{version}_{name}.csv'),index=False)
        pd.DataFrame({'fpr':roc_fpr,'tpr':roc_tpr}).to_csv(os.path.join(OUT,f'roc_{version}_{name}.csv'),index=False)
        pd.DataFrame({'predicted':cpred,'observed':ctrue}).to_csv(os.path.join(OUT,f'cal_{version}_{name}.csv'),index=False)
        calbins.to_csv(os.path.join(OUT,f'calibration_bins_{version}_{name}.csv'),index=False)

metrics_df=pd.DataFrame(metrics); metrics_df.to_csv(os.path.join(OUT,'model_metrics.csv'),index=False)

# Model deltas: near-arrival vs booking time.
mb=metrics_df.pivot(index='model',columns='version',values=['roc_auc','average_precision','brier','ece_10']).reset_index()
mb.columns=['_'.join([str(x) for x in col if x]) for col in mb.columns]
mb.to_csv(os.path.join(OUT,'model_version_delta.csv'),index=False)

# SHAP global and local explanations for gradient boosting.
for version in ['booking_time','near_arrival']:
    pack=models[(version,'gradient_boosting')]; model=pack['model']; pre=model.named_steps['pre']; clf=model.named_steps['clf']
    Xtest=pre.transform(df.loc[te,pack['features']])
    rng=np.random.default_rng(42); idx=rng.choice(Xtest.shape[0],size=min(1200,Xtest.shape[0]),replace=False)
    Xs=Xtest[idx]
    expl=shap.TreeExplainer(clf); sv=expl.shap_values(Xs)
    if isinstance(sv,list): sv=sv[1]
    if hasattr(sv,'toarray'): sv=sv.toarray()
    sv=np.asarray(sv)
    if sv.ndim==3: sv=np.squeeze(sv,axis=-1)
    fn=pre.get_feature_names_out(); mean_abs=np.abs(sv).mean(axis=0); mean_signed=sv.mean(axis=0)
    imp=pd.DataFrame({'feature_encoded':fn,'mean_abs_shap':mean_abs,'mean_shap_logodds':mean_signed}).sort_values('mean_abs_shap',ascending=False)
    imp.to_csv(os.path.join(OUT,f'shap_encoded_{version}.csv'),index=False)
    # map encoded feature back to source feature; one-hot groups are summed.
    def base_name(encoded):
        s=encoded.split('__',1)[-1]
        for pfx in ['country_','meal_','market_segment_','distribution_channel_','reserved_room_type_','deposit_type_','customer_type_','assigned_room_type_']:
            if s.startswith(pfx): return pfx[:-1]
        return s
    imp['feature']=imp.feature_encoded.map(base_name)
    grp=imp.groupby('feature',as_index=False).agg(mean_abs_shap=('mean_abs_shap','sum'),mean_shap_logodds=('mean_shap_logodds','sum')).sort_values('mean_abs_shap',ascending=False)
    grp.to_csv(os.path.join(OUT,f'shap_grouped_{version}.csv'),index=False)
    # local cases at 10th/50th/90th percentile predicted cancellation risk
    ptest=pack['p_test']; test_pos=np.flatnonzero(te.to_numpy()); order=np.argsort(ptest); choices=[order[int(.10*len(order))],order[int(.50*len(order))],order[int(.90*len(order))]]
    Xc=pre.transform(df.iloc[test_pos[choices]][pack['features']]); svc=expl.shap_values(Xc)
    if isinstance(svc,list): svc=svc[1]
    if hasattr(svc,'toarray'): svc=svc.toarray()
    svc=np.asarray(svc); 
    if svc.ndim==3: svc=np.squeeze(svc,axis=-1)
    local=[]
    for j,ri in enumerate(test_pos[choices]):
        top=np.argsort(np.abs(svc[j]))[::-1][:8]
        for k in top:
            enc=fn[k]; base=base_name(enc)
            local.append({'case':j+1,'risk_percentile':[10,50,90][j],'booking_date':str(df.iloc[ri].booking_date.date()),'arrival_date':str(df.iloc[ri].arrival_date.date()),'actual_canceled':int(df.iloc[ri].is_canceled),'pred_cancel_prob':float(ptest[choices[j]]),'feature':base,'feature_encoded':enc,'feature_value':str(df.iloc[ri][base]) if base in df.columns else '', 'shap_value_logodds':float(svc[j,k]),'direction':'increases cancellation risk' if svc[j,k]>0 else 'decreases cancellation risk'})
    pd.DataFrame(local).to_csv(os.path.join(OUT,f'shap_local_{version}.csv'),index=False)

# Overbooking policy using calibrated booking-time GBM probabilities.
test=df.loc[te].copy(); pack=models[('booking_time','gradient_boosting')]; test['p_cancel']=pack['p_test']; test['p_show']=1-test['p_cancel']
# Model assumptions because room inventory is not in the supplied dataset.
CAP_BASE=60
walk_costs={'Low':125.0,'Base':200.0,'High':300.0}
completed=(tr)&(df.is_canceled.eq(0))&(df.adr>0)
ROOM_RATE=float(df.loc[completed,'adr'].median())

def poisson_binomial_probs(ps):
    dist=np.array([1.0])
    for pp in ps: dist=np.convolve(dist,[1-pp,pp])
    return dist

def expected_profit_table(cap,ks,walk_costs):
    out=[]
    # Cache distributions and show-up stats per date,k, so walk-cost scenarios are cheap.
    cache={}
    groups=list(test.groupby('arrival_date',sort=True))
    for k in ks:
        K=cap+k; rows_by_cost={c:[] for c in walk_costs}; avg_show=[];avg_walk=[];avg_acc=[]
        for date,g in groups:
            g2=g.sort_values('p_cancel',ascending=True).head(K)
            ps=g2.p_show.to_numpy(); dist=poisson_binomial_probs(ps); s=np.arange(len(dist)); walk=np.maximum(s-cap,0)
            expected_show=float((dist*s).sum()); expected_walk=float((dist*walk).sum());
            for c,wc in walk_costs.items():
                profit=ROOM_RATE*np.minimum(s,cap)-wc*walk
                rows_by_cost[c].append(float((dist*profit).sum()))
            avg_show.append(expected_show);avg_walk.append(expected_walk);avg_acc.append(len(g2))
        for c in walk_costs:
            out.append({'capacity_rooms':cap,'overbooking_k':k,'walk_scenario':c,'walk_cost_eur':walk_costs[c],'avg_nightly_profit_eur':np.mean(rows_by_cost[c]),'avg_expected_showups':np.mean(avg_show),'avg_expected_walked':np.mean(avg_walk),'avg_accepted_bookings':np.mean(avg_acc)})
    return pd.DataFrame(out)

ob=expected_profit_table(CAP_BASE,range(0,31),walk_costs); ob.to_csv(os.path.join(OUT,'overbooking_profit_curve.csv'),index=False)
ob_best=ob.loc[ob.groupby('walk_scenario').avg_nightly_profit_eur.idxmax()].sort_values('walk_scenario').reset_index(drop=True); ob_best.to_csv(os.path.join(OUT,'overbooking_optima.csv'),index=False)
base0=ob[(ob.capacity_rooms==CAP_BASE)&(ob.walk_scenario=='Base')&(ob.overbooking_k==0)].iloc[0]
basebest=ob[(ob.capacity_rooms==CAP_BASE)&(ob.walk_scenario=='Base')].sort_values('avg_nightly_profit_eur',ascending=False).iloc[0]
profit_gain=float(basebest.avg_nightly_profit_eur-base0.avg_nightly_profit_eur)

# Capacity x walk-cost sensitivity; exact expected profit, five capacities. One pass per cap and k.
sens=[]
for cap in [40,50,60,70,80]:
    tab=expected_profit_table(cap,range(0,31),walk_costs={'x':200.0})
    for _,r in tab.iterrows(): sens.append({'capacity_rooms':cap,'overbooking_k':int(r.overbooking_k),'walk_cost_eur':200.0,'avg_nightly_profit_eur':float(r.avg_nightly_profit_eur)})
sensdf=pd.DataFrame(sens); sensdf.to_csv(os.path.join(OUT,'overbooking_capacity_sensitivity.csv'),index=False)
# Optimal k by capacity and walk-cost scenario using a single analytic distribution pass per cap/k.
opt_sens=[]
for cap in [40,50,60,70,80]:
    tab=expected_profit_table(cap,range(0,31),walk_costs)
    for sc in walk_costs:
        rr=tab[tab.walk_scenario==sc].sort_values('avg_nightly_profit_eur',ascending=False).iloc[0]
        opt_sens.append({'capacity_rooms':cap,'walk_scenario':sc,'walk_cost_eur':walk_costs[sc],'optimal_k':int(rr.overbooking_k),'avg_nightly_profit_eur':float(rr.avg_nightly_profit_eur)})
pd.DataFrame(opt_sens).to_csv(os.path.join(OUT,'overbooking_optimal_sensitivity.csv'),index=False)

# Deposit policy: risk tiers using booking-time GBM probabilities, excluding Non Refund / Groups / Offline TA-TO because EDA shows those are process/channel effects rather than a clean deposit lever.
test['eligible_policy']=(~test.deposit_type.eq('Non Refund')) & (~test.market_segment.isin(['Groups','Offline TA/TO']))
test['risk_tier']=pd.cut(test.p_cancel,bins=[-1,0.20,0.40,1.01],labels=['Low risk','Medium risk','High risk'])
test['room_value']=test.adr.clip(lower=0)*test.total_nights.clip(lower=0)
assumptions=pd.DataFrame([
 {'tier':'Low risk','risk_band':'<20%','deposit_pct':0.00,'cancel_deterrence':0.00,'booking_loss':0.00,'recommendation':'No deposit'},
 {'tier':'Medium risk','risk_band':'20%-40%','deposit_pct':0.10,'cancel_deterrence':0.20,'booking_loss':0.04,'recommendation':'10% deposit'},
 {'tier':'High risk','risk_band':'>40%','deposit_pct':0.25,'cancel_deterrence':0.35,'booking_loss':0.08,'recommendation':'25% deposit'},
])
rows=[]
for _,a in assumptions.iterrows():
    m=(test.risk_tier.eq(a.tier))&test.eligible_policy
    n=int(m.sum()); p=test.loc[m,'p_cancel'].to_numpy(); v=test.loc[m,'room_value'].to_numpy()
    exp_cancel=float(p.sum()); avgp=float(np.mean(p)) if n else np.nan; actual=float(test.loc[m,'is_canceled'].mean()) if n else np.nan; avgval=float(np.mean(v)) if n else 0
    # Sequential assumptions: some customers drop because of the deposit; among retained bookings, cancellations fall by deterrence rate.
    retained_bookings=n*(1-a.booking_loss)
    prevented=exp_cancel*(1-a.booking_loss)*a.cancel_deterrence
    lost_bookings=n*a.booking_loss
    retained_rev=prevented*avgval
    lost_rev=lost_bookings*(1-avgp)*avgval
    net=retained_rev-lost_rev
    rows.append({'tier':a.tier,'risk_band':a.risk_band,'eligible_bookings':n,'share_eligible':n/max(1,int(test.eligible_policy.sum())),'avg_pred_cancel':avgp,'observed_cancel_rate':actual,'deposit_pct':a.deposit_pct,'assumed_cancel_reduction':a.cancel_deterrence,'assumed_booking_loss_rate':a.booking_loss,'expected_cancellations':exp_cancel,'expected_cancellations_prevented':prevented,'expected_bookings_lost':lost_bookings,'avg_room_value_eur':avgval,'retained_revenue_eur':retained_rev,'lost_revenue_eur':lost_rev,'net_incremental_revenue_eur':net,'recommendation':a.recommendation})
dep=pd.DataFrame(rows); dep.to_csv(os.path.join(OUT,'deposit_policy_tiers.csv'),index=False)
dep_total={
'eligible_test_bookings':int(test.eligible_policy.sum()),
'expected_cancellations_prevented':float(dep.expected_cancellations_prevented.sum()),
'expected_bookings_lost':float(dep.expected_bookings_lost.sum()),
'net_incremental_revenue_eur':float(dep.net_incremental_revenue_eur.sum()),
}
# Baseline expected room revenue on the same eligible test bookings; policy comparison excludes deposit-type process segments intentionally.
elig=test.eligible_policy.to_numpy(); baseline_rev=float((test.loc[elig,'p_show']*test.loc[elig,'room_value']).sum()); new_rev=baseline_rev+dep_total['net_incremental_revenue_eur']
dep_total.update({'baseline_expected_room_revenue_eur':baseline_rev,'policy_expected_room_revenue_eur':new_rev,'baseline_cancel_value_loss_eur':float((test.loc[elig,'p_cancel']*test.loc[elig,'room_value']).sum())})
pd.DataFrame([dep_total]).to_csv(os.path.join(OUT,'deposit_policy_summary.csv'),index=False)

# Deposit trade-off: cumulative policy choices on eligible test bookings.
# Start with medium only, then medium+high.
trade=[]
for scope in ['Medium risk only','Medium + High risk']:
    m=(test.eligible_policy & test.risk_tier.eq('Medium risk'))
    if scope!='Medium risk only': m=m|(test.eligible_policy & test.risk_tier.eq('High risk'))
    chosen=dep[dep.tier.isin(['Medium risk'] if scope=='Medium risk only' else ['Medium risk','High risk'])]
    trade.append({'scope':scope,'expected_cancellations_prevented':float(chosen.expected_cancellations_prevented.sum()),'expected_bookings_lost':float(chosen.expected_bookings_lost.sum()),'net_incremental_revenue_eur':float(chosen.net_incremental_revenue_eur.sum())})
trade_df=pd.DataFrame(trade); trade_df.to_csv(os.path.join(OUT,'deposit_tradeoff.csv'),index=False)
# Sensitivity across deterrence and booking-loss assumptions for the recommended targeted tiers.
rows=[]
for md in [0.10,0.20,0.30,0.40]:
 for hd in [0.20,0.35,0.50]:
  for ml in [0.02,0.04,0.06]:
   for hl in [0.04,0.08,0.12]:
    total_prev=total_lost=net=0
    for _,r in dep.iterrows():
        if r.tier=='Medium risk': det,loss=md,ml
        elif r.tier=='High risk': det,loss=hd,hl
        else: det,loss=0,0
        prev=r.expected_cancellations*(1-loss)*det; lost=r.eligible_bookings*loss; ret=prev*r.avg_room_value_eur; lostrev=lost*(1-r.avg_pred_cancel)*r.avg_room_value_eur
        total_prev+=prev; total_lost+=lost; net+=ret-lostrev
    rows.append({'medium_deterrence':md,'high_deterrence':hd,'medium_booking_loss':ml,'high_booking_loss':hl,'cancellations_prevented':total_prev,'bookings_lost':total_lost,'net_incremental_revenue_eur':net})
dep_sens=pd.DataFrame(rows); dep_sens.to_csv(os.path.join(OUT,'deposit_sensitivity.csv'),index=False)

# Charts
# Profit curve
plt.figure(figsize=(8,5))
for sc in ['Low','Base','High']:
    g=ob[ob.walk_scenario==sc]
    plt.plot(g.overbooking_k,g.avg_nightly_profit_eur,marker='o',label=sc)
plt.axvline(int(basebest.overbooking_k),linestyle='--',linewidth=1)
plt.xlabel('Overbooking level (rooms above assumed 60-room capacity)');plt.ylabel('Expected nightly room profit (€)');plt.title('Overbooking profit curve — base capacity assumption');plt.legend();plt.tight_layout();plt.savefig(os.path.join(OUT,'profit_curve.png'),dpi=180);plt.close()
# PR booking-time
plt.figure(figsize=(8,5))
for name,label in [('logistic','Logistic regression'),('gradient_boosting','Gradient boosting')]:
    g=pd.read_csv(os.path.join(OUT,f'pr_booking_time_{name}.csv'));plt.plot(g.recall,g.precision,label=label)
plt.xlabel('Recall');plt.ylabel('Precision');plt.title('Precision–Recall — booking-time models');plt.legend();plt.tight_layout();plt.savefig(os.path.join(OUT,'pr_curve_booking_time.png'),dpi=180);plt.close()
# Calibration booking-time
plt.figure(figsize=(8,5))
for name,label in [('logistic','Logistic regression'),('gradient_boosting','Gradient boosting')]:
    g=pd.read_csv(os.path.join(OUT,f'cal_booking_time_{name}.csv'));plt.plot(g.predicted,g.observed,marker='o',label=label)
plt.plot([0,1],[0,1],linestyle='--',label='Perfect calibration')
plt.xlabel('Predicted cancellation probability');plt.ylabel('Observed cancellation rate');plt.title('Calibration — booking-time models');plt.legend();plt.tight_layout();plt.savefig(os.path.join(OUT,'calibration_booking_time.png'),dpi=180);plt.close()
# Deposit trade-off
plt.figure(figsize=(7,5));plt.scatter(trade_df.expected_cancellations_prevented,trade_df.expected_bookings_lost,s=90)
for _,r in trade_df.iterrows(): plt.annotate(r.scope,(r.expected_cancellations_prevented,r.expected_bookings_lost),xytext=(7,7),textcoords='offset points',fontsize=9)
plt.xlabel('Expected cancellations prevented');plt.ylabel('Expected bookings lost');plt.title('Deposit policy trade-off');plt.tight_layout();plt.savefig(os.path.join(OUT,'deposit_tradeoff.png'),dpi=180);plt.close()
# Optimal k heatmap data visualization (simple matrix plot)
heat=pd.read_csv(os.path.join(OUT,'overbooking_optimal_sensitivity.csv')).pivot(index='capacity_rooms',columns='walk_scenario',values='optimal_k')
plt.figure(figsize=(6,5));plt.imshow(heat.values,aspect='auto',interpolation='nearest');plt.xticks(range(len(heat.columns)),heat.columns);plt.yticks(range(len(heat.index)),heat.index);plt.xlabel('Walk-cost scenario');plt.ylabel('Assumed capacity (rooms)');plt.title('Optimal overbooking level sensitivity')
for i in range(len(heat.index)):
  for j in range(len(heat.columns)): plt.text(j,i,str(int(heat.values[i,j])),ha='center',va='center')
plt.colorbar(label='Optimal overbooking rooms');plt.tight_layout();plt.savefig(os.path.join(OUT,'overbooking_sensitivity_heatmap.png'),dpi=180);plt.close()

# Persist scored test data for policy backtesting.
score_cols=['booking_date','arrival_date','lead_time','market_segment','distribution_channel','deposit_type','customer_type','adr','total_nights','is_canceled','p_cancel','p_show','eligible_policy','risk_tier','room_value']
test[score_cols].to_csv(os.path.join(OUT,'test_scored_bookings.csv'),index=False)
meta={
'split':{'train_end':str(cut70.date()),'calibration_end':str(cut85.date()),'test_start':str((cut85+pd.Timedelta(days=1)).date()),'train_n':int(tr.sum()),'calibration_n':int(ca.sum()),'test_n':int(te.sum())},
'overbooking':{'base_capacity_rooms':CAP_BASE,'room_rate_eur':ROOM_RATE,'walk_costs_eur':walk_costs,'base_walk_scenario':'Base','base_optimal_k':int(basebest.overbooking_k),'base_no_overbook_profit_eur':float(base0.avg_nightly_profit_eur),'base_optimal_profit_eur':float(basebest.avg_nightly_profit_eur),'base_profit_uplift_eur_per_night':profit_gain},
'deposit_assumptions':assumptions.to_dict(orient='records'),
'policy_exclusions':['Non Refund deposit_type','Groups market_segment','Offline TA/TO market_segment'],
'source_note':'Analysis is based on the uploaded cleaned City Hotel subset. Weather and Google Trends files were absent from the bundle and are not used.'}
json.dump(meta,open(os.path.join(OUT,'run_metadata.json'),'w'),indent=2)
print('FINAL METRICS')
print(metrics_df.to_string(index=False))
print('\nOVERBOOKING OPTIMA')
print(ob_best.to_string(index=False))
print('\nDEPOSIT TIERS')
print(dep.to_string(index=False))
print('\nDEPOSIT SUMMARY',dep_total)
print('outputs',OUT)
