import os, json, math, warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from lightgbm import LGBMClassifier
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, precision_recall_curve, roc_curve
from sklearn.calibration import calibration_curve
from sklearn.base import clone
from scipy.special import expit, logit
import shap

BASE='/mnt/data/city_hotel_prompt2'
OUT=os.path.join(BASE,'analysis')
os.makedirs(OUT,exist_ok=True)
df=pd.read_csv(os.path.join(BASE,'data/processed/city_hotel_clean.csv'), parse_dates=['arrival_date','booking_date'])

y=df['is_canceled'].astype(int)
# Drop constant / ID-ish / post-outcome fields. Booking/arrival dates are only used for temporal split.
base_features = [
    'lead_time','arrival_month','arrival_dow','stays_in_weekend_nights','stays_in_week_nights','total_nights',
    'adults','children','babies','total_guests','meal','country','market_segment','distribution_channel',
    'is_repeated_guest','previous_cancellations','previous_bookings_not_canceled','reserved_room_type',
    'deposit_type','has_agent','has_company','days_in_waiting_list','customer_type','adr','is_free_stay',
    'is_zero_night','required_car_parking_spaces','total_of_special_requests','booking_dow','booking_month',
    'is_arrival_holiday','days_to_nearest_holiday'
]
near_features = base_features + ['assigned_room_type','booking_changes','room_type_changed']

# time split 70/15/15 based on booking date, with calibration set between training and final test
q70=df['booking_date'].quantile(0.70)
q85=df['booking_date'].quantile(0.85)
train_mask=df.booking_date<=q70
cal_mask=(df.booking_date>q70)&(df.booking_date<=q85)
test_mask=df.booking_date>q85
print('cutoffs', q70, q85, 'counts', train_mask.sum(),cal_mask.sum(),test_mask.sum())

# Preprocessing
cat_cols=[c for c in base_features if df[c].dtype=='object']
num_cols=[c for c in base_features if c not in cat_cols]
cat_cols_near=[c for c in near_features if df[c].dtype=='object']
num_cols_near=[c for c in near_features if c not in cat_cols_near]

def prep(cat_cols,num_cols):
    return ColumnTransformer([
        ('num', Pipeline([('imp',SimpleImputer(strategy='median')),('sc',StandardScaler())]), num_cols),
        ('cat', Pipeline([('imp',SimpleImputer(strategy='most_frequent')),('oh',OneHotEncoder(handle_unknown='ignore',min_frequency=3))]), cat_cols)
    ], remainder='drop')

def platt_calibrate(p_cal,y_cal,p_test):
    z=logit(np.clip(p_cal,1e-6,1-1e-6)).reshape(-1,1)
    zt=logit(np.clip(p_test,1e-6,1-1e-6)).reshape(-1,1)
    cal=LogisticRegression(C=1e6, solver='lbfgs')
    cal.fit(z,y_cal)
    return cal.predict_proba(zt)[:,1], cal

def ece(y_true,pred,n_bins=10):
    bins=np.linspace(0,1,n_bins+1)
    idx=np.digitize(pred,bins[1:-1],right=False)
    total=len(y_true); out=0.0
    rows=[]
    for b in range(n_bins):
        m=idx==b
        if m.sum()==0: continue
        avgp=pred[m].mean(); avgy=y_true[m].mean(); w=m.sum()/total
        out += w*abs(avgp-avgy)
        rows.append((b,m.sum(),avgp,avgy))
    return out, rows

results=[]
models={}
for version, features, cats, nums in [('booking_time',base_features,cat_cols,num_cols),('near_arrival',near_features,cat_cols_near,num_cols_near)]:
  X=df[features]
  pre=prep(cats,nums)
  lr=Pipeline([('pre',pre),('clf',LogisticRegression(C=1.0,max_iter=1000,solver='liblinear'))])
  gb=Pipeline([('pre',clone(pre)),('clf',LGBMClassifier(n_estimators=350,learning_rate=0.035,num_leaves=31,subsample=0.9,colsample_bytree=0.85,reg_lambda=2.0,random_state=42,n_jobs=-1,verbosity=-1))])
  for name,model in [('logistic',lr),('gradient_boosting',gb)]:
    model.fit(X[train_mask], y[train_mask])
    p_cal_raw=model.predict_proba(X[cal_mask])[:,1]
    p_test_raw=model.predict_proba(X[test_mask])[:,1]
    p_test_cal, cal=platt_calibrate(p_cal_raw,y[cal_mask],p_test_raw)
    p_cal_cal, _ = platt_calibrate(p_cal_raw,y[cal_mask],p_cal_raw)
    auc=roc_auc_score(y[test_mask],p_test_cal)
    ap=average_precision_score(y[test_mask],p_test_cal)
    brier=brier_score_loss(y[test_mask],p_test_cal)
    ece_v, bins=ece(y[test_mask].to_numpy(),p_test_cal,10)
    results.append({'version':version,'model':name,'train_n':int(train_mask.sum()),'calibration_n':int(cal_mask.sum()),'test_n':int(test_mask.sum()),'test_cancel_rate':float(y[test_mask].mean()),'roc_auc':auc,'avg_precision':ap,'brier':brier,'ece_10':ece_v})
    models[(version,name)]={'model':model,'calibrator':cal,'p_test':p_test_cal,'p_cal_raw':p_cal_raw,'p_test_raw':p_test_raw,'features':features}
    # save PR / calibration points
    prec,rec,_=precision_recall_curve(y[test_mask],p_test_cal)
    fpr,tpr,_=roc_curve(y[test_mask],p_test_cal)
    cal_true, cal_pred=calibration_curve(y[test_mask],p_test_cal,n_bins=10,strategy='quantile')
    pd.DataFrame({'precision':prec,'recall':rec}).to_csv(os.path.join(OUT,f'pr_{version}_{name}.csv'),index=False)
    pd.DataFrame({'fpr':fpr,'tpr':tpr}).to_csv(os.path.join(OUT,f'roc_{version}_{name}.csv'),index=False)
    pd.DataFrame({'predicted':cal_pred,'observed':cal_true}).to_csv(os.path.join(OUT,f'cal_{version}_{name}.csv'),index=False)

res=pd.DataFrame(results)
res.to_csv(os.path.join(OUT,'model_metrics.csv'),index=False)
print(res.to_string(index=False))

# SHAP for booking-time gradient boosting and near-arrival gradient boosting.
for version in ['booking_time','near_arrival']:
  pack=models[(version,'gradient_boosting')]
  model=pack['model']
  # transformed test sample
  pre=model.named_steps['pre']; clf=model.named_steps['clf']
  Xtest=pre.transform(df.loc[test_mask, pack['features']])
  # sample up to 1200 for speed
  rng=np.random.default_rng(42); idx=rng.choice(Xtest.shape[0], size=min(1200,Xtest.shape[0]), replace=False)
  Xs=Xtest[idx]
  expl=shap.TreeExplainer(clf)
  sv=expl.shap_values(Xs)
  if isinstance(sv,list): sv=sv[1]
  if hasattr(sv,'toarray'): sv=sv.toarray()
  else: sv=np.asarray(sv)
  if sv.ndim==3: sv=np.squeeze(sv,axis=-1)
  fn=pre.get_feature_names_out()
  mean_abs=np.abs(sv).mean(axis=0)
  shap_imp=pd.DataFrame({'feature_encoded':fn,'mean_abs_shap':mean_abs}).sort_values('mean_abs_shap',ascending=False)
  shap_imp.to_csv(os.path.join(OUT,f'shap_global_{version}.csv'),index=False)
  # aggregate one-hot groups to original features by prefix
  groups=[]
  for f,v in zip(fn,mean_abs):
      key=f.split('__',1)[-1]
      # map categorical one-hot back to base feature prefix before category text
      base=key
      if base.startswith('country_'): base='country'
      elif base.startswith('meal_'): base='meal'
      elif base.startswith('market_segment_'): base='market_segment'
      elif base.startswith('distribution_channel_'): base='distribution_channel'
      elif base.startswith('reserved_room_type_'): base='reserved_room_type'
      elif base.startswith('deposit_type_'): base='deposit_type'
      elif base.startswith('customer_type_'): base='customer_type'
      elif base.startswith('assigned_room_type_'): base='assigned_room_type'
      groups.append((base,v))
  grp=pd.DataFrame(groups,columns=['feature','mean_abs_shap']).groupby('feature',as_index=False).sum().sort_values('mean_abs_shap',ascending=False)
  grp.to_csv(os.path.join(OUT,f'shap_grouped_{version}.csv'),index=False)
  # Local explanations: top absolute SHAP for 3 test observations with varied risk
  ptest=pack['p_test']
  test_indices=np.where(test_mask.to_numpy())[0]
  # choose low/medium/high risk among test
  order=np.argsort(ptest)
  choices=[order[int(0.10*len(order))],order[int(0.50*len(order))],order[int(0.90*len(order))]]
  # recompute shap for these rows
  Xchoices=pre.transform(df.loc[test_indices[choices],pack['features']])
  sv2=expl.shap_values(Xchoices)
  if isinstance(sv2,list): sv2=sv2[1]
  if hasattr(sv2,'toarray'): sv2=sv2.toarray()
  else: sv2=np.asarray(sv2)
  if sv2.ndim==3: sv2=np.squeeze(sv2,axis=-1)
  local=[]
  for j,row_idx in enumerate(test_indices[choices]):
      row_sv=sv2[j]
      top=np.argsort(np.abs(row_sv))[::-1][:8]
      for k in top:
          local.append({'case':j+1,'booking_date':str(df.iloc[row_idx].booking_date.date()),'arrival_date':str(df.iloc[row_idx].arrival_date.date()),'actual_canceled':int(df.iloc[row_idx].is_canceled),'pred_cancel_prob':float(ptest[choices[j]]),'feature_encoded':fn[k],'shap_value_logodds':float(row_sv[k]),'feature_value':str(df.iloc[row_idx].get(fn[k].split('__',1)[-1].split('_',1)[0],''))})
  pd.DataFrame(local).to_csv(os.path.join(OUT,f'shap_local_{version}.csv'),index=False)

# Overbooking simulation. Use calibrated booking-time GBM probabilities for test bookings.
pack=models[('booking_time','gradient_boosting')]
ptest=pack['p_test']; test=df.loc[test_mask].copy()
test['p_cancel']=ptest
test['p_show']=1-test['p_cancel']
# room capacity assumption: 100 rooms/night in the modeled inventory slice; user can vary in Sensitivity.
# This is an explicit model assumption because source data contains reservations, not room-inventory capacity.
CAP=100
# Base room revenue assumption: use median realized ADR of completed bookings in training period.
adr_completed=train_mask & (df.is_canceled==0) & (df.adr>0)
ROOM_RATE=float(df.loc[adr_completed,'adr'].median())
# cost scenarios for walking; all values in EUR per walked room.
walk_scenarios={'Low':125.0,'Base':200.0,'High':300.0}
# simulate expected show-ups deterministically via 1,500 Bernoulli draws per night? Use binomial per booking with p; repeat simulation using shared seed.
rng=np.random.default_rng(123)
B=2000
rows=[]
# For each date, accept at most CAP+k reservations, prioritizing lowest p_cancel (highest show-up likelihood).
for k in range(0,31):
  K=CAP+k
  profit_by={s:[] for s in walk_scenarios}
  showups_all=[]; accepted_all=[]; walked_all=[]; rev_all=[]
  for date,g in test.groupby('arrival_date',sort=True):
      # accept K bookings if demand exceeds K
      g2=g.sort_values('p_cancel',ascending=True).head(K).copy()
      if len(g2)==0: continue
      p=g2.p_show.to_numpy()
      # aggregate B simulation draws
      # chunk: B x n can be big, but n<=164, 793 nights => ~5m manageable for each k too expensive; use expected value via 2k sims per night across selected.
      sim=(rng.random((B,len(p))) < p[None,:]).sum(axis=1)
      for s,walk_cost in walk_scenarios.items():
          walked=np.maximum(sim-CAP,0)
          # Revenue from all show-ups, including walked guests, minus walk cost.
          profit=ROOM_RATE*sim - walk_cost*walked
          profit_by[s].append(profit.mean())
      showups_all.append(np.mean(sim)); accepted_all.append(len(g2)); walked_all.append(np.mean(np.maximum(sim-CAP,0))); rev_all.append(np.mean(ROOM_RATE*sim))
  for s in walk_scenarios:
      rows.append({'overbooking_k':k,'walk_scenario':s,'avg_nightly_profit_eur':float(np.mean(profit_by[s])),'avg_showups':float(np.mean(showups_all)),'avg_accepted':float(np.mean(accepted_all)),'avg_walked':float(np.mean(walked_all)),'avg_room_revenue_eur':float(np.mean(rev_all))})
ob=pd.DataFrame(rows)
ob.to_csv(os.path.join(OUT,'overbooking_profit_curve.csv'),index=False)
print('overbooking optima')
print(ob.loc[ob.groupby('walk_scenario').avg_nightly_profit_eur.idxmax()].sort_values('walk_scenario').to_string(index=False))

# Sensitivity: capacity and room revenue multiplier and walk cost.
sens=[]
for cap in [80,90,100,110,120]:
  for wc in [100,125,150,200,250,300,400]:
    best=None
    for k in range(0,31):
      K=cap+k; profits=[]
      for date,g in test.groupby('arrival_date',sort=True):
        g2=g.sort_values('p_cancel').head(K)
        if len(g2)==0: continue
        p=g2.p_show.to_numpy()
        # analytic expected profit using repeated binomial convolution via DP for Poisson binomial distribution; small n<=164.
        dist=np.array([1.0])
        for pp in p:
            dist=np.convolve(dist,[1-pp,pp])
        svals=np.arange(len(dist))
        prof=ROOM_RATE*svals - wc*np.maximum(svals-cap,0)
        profits.append((dist*prof).sum())
      val=float(np.mean(profits))
      if best is None or val>best[1]: best=(k,val)
    sens.append({'capacity':cap,'walk_cost':wc,'optimal_k':best[0],'avg_nightly_profit_eur':best[1]})
ss=pd.DataFrame(sens); ss.to_csv(os.path.join(OUT,'overbooking_sensitivity.csv'),index=False)

# Baseline no-overbook vs optimal base walk cost using same policy acceptance framework.
def expected_profit_for_k(cap,k,wc):
    K=cap+k; profits=[]; show=[]; walked=[]; acc=[]
    for date,g in test.groupby('arrival_date',sort=True):
        g2=g.sort_values('p_cancel').head(K)
        p=g2.p_show.to_numpy()
        dist=np.array([1.0])
        for pp in p: dist=np.convolve(dist,[1-pp,pp])
        svals=np.arange(len(dist))
        profits.append(float((dist*(ROOM_RATE*svals-wc*np.maximum(svals-cap,0))).sum()))
        show.append(float((dist*svals).sum())); walked.append(float((dist*np.maximum(svals-cap,0)).sum())); acc.append(len(g2))
    return np.mean(profits),np.mean(show),np.mean(walked),np.mean(acc)

# Deposit policy simulation, based on model risk tiers and transparent deterrence / conversion assumptions.
# Base assumptions: targeted transient bookings only; channel block-allotment Non Refund is excluded from lever.
# risk tiers: p_cancel < 0.20 no deposit; 0.20-0.40 10%; >0.40 25%; booking loss assumptions 0%, 4%, 8%; cancellation reduction assumptions 0%, 20%, 35%.
# Financial effect uses room revenue ADR * total_nights; deposits are treated as deterrents, not revenue, to avoid double counting without evidence.
deposit_assumptions=[
 {'tier':'Low risk','lo':0.0,'hi':0.20,'deposit_pct':0.00,'cancel_deterrence':0.00,'booking_loss':0.00},
 {'tier':'Medium risk','lo':0.20,'hi':0.40,'deposit_pct':0.10,'cancel_deterrence':0.20,'booking_loss':0.04},
 {'tier':'High risk','lo':0.40,'hi':1.01,'deposit_pct':0.25,'cancel_deterrence':0.35,'booking_loss':0.08},
]
# exclude Non Refund + Groups/Offline TA-TO from policy targeting, per data composition issue.
eligible=~test.deposit_type.isin(['Non Refund']) & ~test.market_segment.isin(['Groups','Offline TA/TO'])
test['policy_eligible']=eligible
test['risk_tier']=pd.cut(test.p_cancel, bins=[-1,0.2,0.4,1.01], labels=['Low risk','Medium risk','High risk'])
test['room_value']=test.adr.clip(lower=0)*test.total_nights.clip(lower=0)

dep_rows=[]
for a in deposit_assumptions:
  m=(test.risk_tier==a['tier']) & test.policy_eligible
  n=int(m.sum())
  expected_cancels=float(test.loc[m,'p_cancel'].sum())
  prevented=expected_cancels*a['cancel_deterrence']
  # expected booking loss = bookings * conversion loss; these are modeled as lost bookings (revenue opportunity), not necessarily cancellations.
  lost_bookings=n*a['booking_loss']
  # expected revenue retained = prevented cancellations weighted by room value; use avg room value in tier as an approximation
  avg_val=float(test.loc[m,'room_value'].mean()) if n else 0.0
  retained=prevented*avg_val
  lost_rev=lost_bookings*avg_val*(1-a['cancel_deterrence'])
  net=retained-lost_rev
  dep_rows.append({'tier':a['tier'],'bookings_eligible':n,'share_of_test_eligible':n/max(1,int(eligible.sum())),'avg_pred_cancel':float(test.loc[m,'p_cancel'].mean()) if n else np.nan,'deposit_pct':a['deposit_pct'],'assumed_cancel_reduction':a['cancel_deterrence'],'assumed_booking_loss_rate':a['booking_loss'],'expected_cancellations':expected_cancels,'expected_cancellations_prevented':prevented,'expected_bookings_lost':lost_bookings,'avg_room_value_eur':avg_val,'retained_revenue_eur':retained,'lost_revenue_eur':lost_rev,'net_impact_eur':net})

dep_tiers=pd.DataFrame(dep_rows)
# policy aggregate across eligible bookings; baseline is no deposit for targeted eligible bookings. Current baseline includes existing deposit statuses across all test bookings.
# simulate recommended policy and compare to baseline using assumptions.
base_eligible=dep_tiers['retained_revenue_eur'].sum(); base_lost=dep_tiers['lost_revenue_eur'].sum(); net=base_eligible-base_lost
# annualize per 793 arrival days across the test period? Test period contains 120-ish days/arrivals. Use per-night and per-booking metrics instead.
# calculate current baseline expected room revenue (p_show * room_value) and expected lost value from cancellation.
expected_baseline_rev=float((test.p_show*test.room_value).sum())
expected_baseline_lost=float((test.p_cancel*test.room_value).sum())
expected_new_rev=expected_baseline_rev+net
# net per 100 eligible bookings, per test period.
dep_summary={'eligible_test_bookings':int(eligible.sum()),'expected_baseline_room_revenue_eur':expected_baseline_rev,'expected_baseline_cancel_revenue_loss_eur':expected_baseline_lost,'policy_incremental_revenue_eur':net,'policy_revised_expected_room_revenue_eur':expected_new_rev,'prevented_cancellations':float(dep_tiers.expected_cancellations_prevented.sum()),'lost_bookings':float(dep_tiers.expected_bookings_lost.sum())}
pd.DataFrame([dep_summary]).to_csv(os.path.join(OUT,'deposit_policy_summary.csv'),index=False)
dep_tiers.to_csv(os.path.join(OUT,'deposit_policy_tiers.csv'),index=False)

# Trade-off and sensitivity for policy assumptions.
trade=[]
for med_det in [0.10,0.20,0.30,0.40]:
 for high_det in [0.20,0.35,0.50]:
  for med_loss in [0.02,0.04,0.06]:
   for high_loss in [0.04,0.08,0.12]:
    prevented=0; lostb=0; retained=0; lostrev=0
    for _,r in dep_tiers.iterrows():
      if r['tier']=='Medium risk': det,loss=med_det,med_loss
      elif r['tier']=='High risk': det,loss=high_det,high_loss
      else: det,loss=0,0
      n=r.bookings_eligible; canc=r.expected_cancellations; av=r.avg_room_value_eur
      p=canc*det; lb=n*loss
      prevented+=p; lostb+=lb; retained+=p*av; lostrev+=lb*av*(1-det)
    trade.append({'medium_deterrence':med_det,'high_deterrence':high_det,'medium_booking_loss':med_loss,'high_booking_loss':high_loss,'cancellations_prevented':prevented,'bookings_lost':lostb,'net_incremental_revenue_eur':retained-lostrev})
trade_df=pd.DataFrame(trade)
trade_df.to_csv(os.path.join(OUT,'deposit_sensitivity.csv'),index=False)

# Recommended policy from base assumptions.
rec=dep_tiers.copy(); rec['recommendation']=rec['tier'].map({'Low risk':'No deposit','Medium risk':'10% deposit','High risk':'25% deposit'})
rec.to_csv(os.path.join(OUT,'deposit_recommendation.csv'),index=False)

# Generate charts.
plt.figure(figsize=(8,5))
for s in walk_scenarios:
    g=ob[ob.walk_scenario==s]
    plt.plot(g.overbooking_k,g.avg_nightly_profit_eur,marker='o',label=s)
plt.xlabel('Overbooking level (rooms above assumed 100-room capacity)'); plt.ylabel('Expected nightly profit (€)'); plt.title('Expected profit vs overbooking level'); plt.legend(); plt.tight_layout(); plt.savefig(os.path.join(OUT,'profit_curve.png'),dpi=180); plt.close()

plt.figure(figsize=(8,5))
for name in ['logistic','gradient_boosting']:
    g=pd.read_csv(os.path.join(OUT,f'pr_booking_time_{name}.csv'))
    plt.plot(g.recall,g.precision,label=name)
plt.xlabel('Recall'); plt.ylabel('Precision'); plt.title('Precision–Recall: booking-time models'); plt.legend(); plt.tight_layout(); plt.savefig(os.path.join(OUT,'pr_curve_booking_time.png'),dpi=180); plt.close()

plt.figure(figsize=(8,5));
for name in ['logistic','gradient_boosting']:
    g=pd.read_csv(os.path.join(OUT,f'cal_booking_time_{name}.csv'))
    plt.plot(g.predicted,g.observed,marker='o',label=name)
plt.plot([0,1],[0,1],linestyle='--'); plt.xlabel('Predicted probability'); plt.ylabel('Observed cancellation rate'); plt.title('Calibration: booking-time models'); plt.legend(); plt.tight_layout(); plt.savefig(os.path.join(OUT,'calibration_booking_time.png'),dpi=180); plt.close()

# Risk-tier tradeoff plot using base assumptions across cumulative tiers
trade_tier=[]; cum_prev=0; cum_lost=0
for _,r in dep_tiers.iterrows():
    cum_prev += r.expected_cancellations_prevented
    cum_lost += r.expected_bookings_lost
    trade_tier.append((r.tier,cum_prev,cum_lost,r.net_impact_eur))
# plot each tier point as standalone
plt.figure(figsize=(7,5));
plt.scatter([0, dep_tiers.expected_cancellations_prevented.iloc[1], dep_tiers.expected_cancellations_prevented.iloc[1]+dep_tiers.expected_cancellations_prevented.iloc[2]], [0, dep_tiers.expected_bookings_lost.iloc[1], dep_tiers.expected_bookings_lost.iloc[1]+dep_tiers.expected_bookings_lost.iloc[2]], s=90)
plt.xlabel('Expected cancellations prevented'); plt.ylabel('Expected bookings lost'); plt.title('Deposit policy trade-off (cumulative targeted tiers)'); plt.tight_layout(); plt.savefig(os.path.join(OUT,'deposit_tradeoff.png'),dpi=180); plt.close()

# save metadata
meta={'split':{'train_end':str(q70.date()),'calibration_end':str(q85.date()),'test_start':str((q85+pd.Timedelta(days=1)).date()),'train_n':int(train_mask.sum()),'calibration_n':int(cal_mask.sum()),'test_n':int(test_mask.sum())},'overbooking':{'capacity_assumption_rooms':CAP,'room_rate_eur':ROOM_RATE,'walk_costs_eur':walk_scenarios},'deposit_policy_assumptions':deposit_assumptions,'source_note':'Dataset is the Hotel Booking Demand City Hotel (H2) subset. External weather and Google Trends files were not present in the uploaded bundle, so they are not used.'}
json.dump(meta,open(os.path.join(OUT,'run_metadata.json'),'w'),indent=2)
print('done',OUT)
